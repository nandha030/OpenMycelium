"""OpenMycelium: one model across two GPU vendors."""

__version__ = "0.1.0a8"
