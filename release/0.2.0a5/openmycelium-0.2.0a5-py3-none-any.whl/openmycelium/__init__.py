"""OpenMycelium: one model across two GPU vendors."""

__version__ = "0.2.0a5"
